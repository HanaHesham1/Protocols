package com.example.catchmeifyoucan;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class waitingRoom extends AppCompatActivity {
    FirebaseDatabase database;

    DatabaseReference myRef1,myRef2,myRef3,myRef4,myRef5,myRef6,nb;
    int count=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_waiting_room);
        database = FirebaseDatabase.getInstance();
        count = getIntent().getIntExtra("count",0);
        TextView msg1 = findViewById(R.id.waiting_player1) ;
        TextView msg2 = findViewById(R.id.waiting_player2) ;
        TextView msg3 = findViewById(R.id.waiting_player3) ;
        TextView msg4 = findViewById(R.id.waiting_player4) ;
        TextView msg5 = findViewById(R.id.waiting_player5) ;
        TextView msg6 = findViewById(R.id.waiting_player6) ;
       nb = database.getReference("game").child("Count");
        nb.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
               count=snapshot.getValue(Integer.class);
                if(count>6){
                    Intent i = new Intent(waitingRoom.this,game.class);
                    startActivity(i);
                    finish();
                }
//                HashMap<String, Object> player1 = (HashMap<String, Object>) snapshot.child("Team 1").child("Player 1").getValue();
//                String name= player1.get("Nickname").toString();
//                msg1.setText(name);
//                if(count>1)
//                    msg1.setVisibility(View.VISIBLE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        myRef1 = database.getReference("game").child("Team 1").child("Player 1").child("Nickname");
        myRef1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //HashMap<String, Object> player = (HashMap<String, Object>) snapshot.getValue();
                String name= snapshot.getValue().toString();
                msg1.setText(name);
                if(!name.equals(""))
                 msg1.setVisibility(View.VISIBLE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        myRef2 = database.getReference("game").child("Team 1").child("Player 2").child("Nickname");
        myRef2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
               // HashMap<String, Object> player = (HashMap<String, Object>) snapshot.getValue();
                String name= snapshot.getValue().toString();
                msg2.setText(name);
                if(!name.equals(""))
                 msg2.setVisibility(View.VISIBLE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        myRef3 = database.getReference("game").child("Team 1").child("Player 3").child("Nickname");
        myRef3.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //HashMap<String, Object> player = (HashMap<String, Object>) snapshot.getValue();
                String name= snapshot.getValue().toString();
                msg3.setText(name);
                if(!name.equals(""))
                    msg3.setVisibility(View.VISIBLE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        myRef4 = database.getReference("game").child("Team 2").child("Player 1").child("Nickname");
        myRef4.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //HashMap<String, Object> player = (HashMap<String, Object>) snapshot.getValue();
                String name= snapshot.getValue().toString();
                msg4.setText(name);
                if(!name.equals(""))
                    msg4.setVisibility(View.VISIBLE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        myRef5 = database.getReference("game").child("Team 2").child("Player 2").child("Nickname");
        myRef5.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //HashMap<String, Object> player = (HashMap<String, Object>) snapshot.getValue();
                String name= snapshot.getValue().toString();
                msg5.setText(name);
                if(!name.equals(""))
                 msg5.setVisibility(View.VISIBLE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        myRef6 = database.getReference("game").child("Team 2").child("Player 3").child("Nickname");
        myRef6.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //HashMap<String, Object> player = (HashMap<String, Object>) snapshot.getValue();
                String name= snapshot.getValue().toString();
                msg6.setText(name);
                if(!name.equals(""))
                 msg6.setVisibility(View.VISIBLE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



//        for(i=1;i<=2;i++){
//            for(j=1;j<=3;j++){
//               // myRef = database.getReference("game").child("Team "+i).child("Player "+j);
//                myRef.addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NonNull DataSnapshot snapshot) {
//                        Toast.makeText(waitingRoom.this, snapshot.toString(), Toast.LENGTH_SHORT).show();
//                        HashMap<String, Object> game = (HashMap<String, Object>) snapshot.getValue();
//                        Toast.makeText(waitingRoom.this, game.get("Team 1").toString(), Toast.LENGTH_SHORT).show();
//                        for (int i = 1 ; i <= 2; i++){
//                            for (int j=1; j<=3;j++ ){
//                                Toast.makeText(waitingRoom.this, game.get("Player "+j).toString(), Toast.LENGTH_SHORT).show();
//
//                            }
//                            Toast.makeText(waitingRoom.this, game.get("Team "+i).get("Player "+j).toString(), Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                        HashMap<String, Object> player = (HashMap<String, Object>) snapshot.getValue();
//                        String name= player.get("Nickname").toString();
//                        if(i==1){
//                            switch(j){
//                                case 1: msg1.setText(name);
//                                        msg1.setVisibility(View.VISIBLE);
//                                        break;
//                                case 2: msg2.setText(name);
//                                        msg2.setVisibility(View.VISIBLE);
//                                        break;
//                                case 3: msg3.setText(name);
//                                        msg3.setVisibility(View.VISIBLE);
//                                        break;
//                                }}
//                                else{
//                                    switch(j) {
//                                        case 1:
//                                            msg4.setText(name);
//                                            msg4.setVisibility(View.VISIBLE);
//                                            break;
//                                        case 2:
//                                            msg5.setText(name);
//                                            msg5.setVisibility(View.VISIBLE);
//                                            break;
//                                        case 3:
//                                            msg6.setText(name);
//                                            msg6.setVisibility(View.VISIBLE);
//                                            break;
//                                    }
//                                    }
//                            }
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError error) {
//
//                    }
//                });
//                }
//        ;}



        }
    }


