package com.example.catchmeifyoucan;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Start extends AppCompatActivity {

    int count ;
    String email;
    FirebaseDatabase database;
    DatabaseReference myRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        FirebaseUser user= FirebaseAuth.getInstance().getCurrentUser();
        database = FirebaseDatabase.getInstance();
       // myRef= database.getReference("game1").child("count");
        email=user.getEmail();

        EditText s = findViewById(R.id.start_name);

        myRef = database.getReference("game").child("Count");
        //myRef.setValue(1);
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override

            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                count = dataSnapshot.getValue(Integer.class);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Start.this,"failed to read data",Toast.LENGTH_SHORT).show();
            }
        });
        findViewById(R.id.start_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(s.getText().toString().isEmpty()){
                    Toast.makeText(Start.this,"enter Username",Toast.LENGTH_SHORT).show();
                    return;}
                if(count>6) {
                    Toast.makeText(Start.this, "Room is full", Toast.LENGTH_SHORT).show();
                    return;
                }
                String x ="Team 1";
                switch (count){
                            case 1 :{ database.getReference("game").child(x).child("Player 1").child("Nickname").setValue(s.getText().toString());
                                database.getReference("game").child("Team 1").child("Player 1").child("Location").child("X").setValue(0);
                                database.getReference("game").child("Team 1").child("Player 1").child("Location").child("Y").setValue(0);
                                database.getReference("game").child("Team 1").child("Player 1").child("Score").setValue(0);
                                database.getReference("game").child("Team 1").child("Player 1").child("Email").setValue(email);
                                break;}
                            case 2 :{database.getReference("game").child("Team 1").child("Player 2").child("Nickname").setValue(s.getText().toString());
                                database.getReference("game").child("Team 1").child("Player 2").child("Location").child("X").setValue(0);
                                database.getReference("game").child("Team 1").child("Player 2").child("Location").child("Y").setValue(0);
                                database.getReference("game").child("Team 1").child("Player 2").child("Score").setValue(0);
                                database.getReference("game").child("Team 1").child("Player 2").child("Email").setValue(email);
                            break;}
                            case 3 :{database.getReference("game").child("Team 1").child("Player 3").child("Nickname").setValue(s.getText().toString());
                                database.getReference("game").child("Team 1").child("Player 3").child("Location").child("X").setValue(0);
                                database.getReference("game").child("Team 1").child("Player 3").child("Location").child("Y").setValue(0);
                                database.getReference("game").child("Team 1").child("Player 3").child("Score").setValue(0);
                                database.getReference("game").child("Team 1").child("Player 3").child("Email").setValue(email);
                                break;}
                            case 4 :{database.getReference("game").child("Team 2").child("Player 1").child("Nickname").setValue(s.getText().toString());
                                database.getReference("game").child("Team 2").child("Player 1").child("Location").child("X").setValue(0);
                                database.getReference("game").child("Team 2").child("Player 1").child("Location").child("Y").setValue(0);
                                database.getReference("game").child("Team 2").child("Player 1").child("Score").setValue(0);
                                database.getReference("game").child("Team 2").child("Player 1").child("Email").setValue(email);
                                break;}
                            case 5 :{database.getReference("game").child("Team 2").child("Player 2").child("Nickname").setValue(s.getText().toString());
                                database.getReference("game").child("Team 2").child("Player 2").child("Location").child("X").setValue(0);
                                database.getReference("game").child("Team 2").child("Player 2").child("Location").child("Y").setValue(0);
                                database.getReference("game").child("Team 2").child("Player 2").child("Score").setValue(0);
                                database.getReference("game").child("Team 2").child("Player 2").child("Email").setValue(email);
                                break;}
                            case 6 :{database.getReference("game").child("Team 2").child("Player 3").child("Nickname").setValue(s.getText().toString());
                                database.getReference("game").child("Team 2").child("Player 3").child("Location").child("X").setValue(0);
                                database.getReference("game").child("Team 2").child("Player 3").child("Location").child("Y").setValue(0);
                                database.getReference("game").child("Team 2").child("Player 3").child("Score").setValue(0);
                                database.getReference("game").child("Team 2").child("Player 3").child("Email").setValue(email);
                                break;}
                            default : ;
                        }

                count=count+1;
               database.getReference("game").child("Count").setValue(count);


//               database.getReference("game").addListenerForSingleValueEvent(new ValueEventListener() {
//                   @Override
//                   public void onDataChange(@NonNull DataSnapshot snapshot) {
//                       String gameData = snapshot.toString();
//                       Log.d("Game Data",gameData);
//
//                   }
//
//                   @Override
//                   public void onCancelled(@NonNull DatabaseError error) {
//                     Log.e("Game Data","Failed to read game Data",error.toException());
//                   }
//               });
                Intent i = new Intent(Start.this,waitingRoom.class);
                i.putExtra("count", count);
                startActivity(i);
                finish();

            }

});
}
    public static void removeListenersFromParentAndChildren( DatabaseReference parentRef , ValueEventListener valueEventListener) {
        // Remove all listeners from the parent reference
        parentRef.removeEventListener(valueEventListener);

        // Get a list of child references
        final List<DatabaseReference> childRefs = new ArrayList<>();

        parentRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                    childRefs.add(childSnapshot.getRef());
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Handle errors here
            }
        });

        // Remove all listeners from the child references
        for (DatabaseReference childRef : childRefs) {
            childRef.removeEventListener(valueEventListener);
        }
    }


}























